# DAY 14 - POWER BI PYTHON VALIDATION
# ------------------------------------
# This code is used to cross-check Power BI results
# with Python using the same Capstone dataset.


# Import Libraries

import pandas as pd


# =========================================================
# PART A - LOAD DATA
# =========================================================

customers = pd.read_csv("Capstone_Customers.csv")
orders = pd.read_csv("Capstone_Orders.csv")


print("Customers Shape:", customers.shape)
print("Orders Shape:", orders.shape)


# =========================================================
# PART B - DATA CLEANING
# =========================================================

# Remove duplicate rows
# This matches the Power Query requirement:
# "remove duplicate rows"

customers = customers.drop_duplicates().copy()
orders = orders.drop_duplicates().copy()


# Clean Region

customers["Region"] = (
    customers["Region"]
    .astype("string")
    .str.strip()
    .str.title()
)


# Clean Segment

customers["Segment"] = (
    customers["Segment"]
    .astype("string")
    .str.strip()
    .str.title()
)


# Clean Category

orders["Category"] = (
    orders["Category"]
    .astype("string")
    .str.strip()
    .str.title()
)


# Convert data types

customers["CustomerID"] = pd.to_numeric(
    customers["CustomerID"],
    errors="coerce"
)

orders["CustomerID"] = pd.to_numeric(
    orders["CustomerID"],
    errors="coerce"
)

orders["OrderID"] = pd.to_numeric(
    orders["OrderID"],
    errors="coerce"
)

orders["Sales"] = pd.to_numeric(
    orders["Sales"],
    errors="coerce"
)

orders["Profit"] = pd.to_numeric(
    orders["Profit"],
    errors="coerce"
)

orders["Quantity"] = pd.to_numeric(
    orders["Quantity"],
    errors="coerce"
)

orders["Discount"] = pd.to_numeric(
    orders["Discount"],
    errors="coerce"
)


# =========================================================
# PART C - MERGE TABLES
# =========================================================

df = pd.merge(
    customers,
    orders,
    on="CustomerID",
    how="inner"
)


print("\nMerged Dataset Shape:", df.shape)


# =========================================================
# PART D - BASIC VALIDATION
# =========================================================

print("\n========== REGION VALUES ==========")

print(
    df["Region"]
    .dropna()
    .unique()
)


print("\n========== CATEGORY VALUES ==========")

print(
    df["Category"]
    .dropna()
    .unique()
)


print("\n========== SEGMENT VALUES ==========")

print(
    df["Segment"]
    .dropna()
    .unique()
)


# =========================================================
# PART E - TOTAL SALES
# =========================================================

total_sales = df["Sales"].sum()

print("\n========== TOTAL SALES ==========")

print("Total Sales:", round(total_sales, 2))


# =========================================================
# PART F - TOTAL PROFIT
# =========================================================

total_profit = df["Profit"].sum()

print("\n========== TOTAL PROFIT ==========")

print("Total Profit:", round(total_profit, 2))


# =========================================================
# PART G - ORDER COUNT
# =========================================================

order_count = df["OrderID"].nunique()

print("\n========== ORDER COUNT ==========")

print("Order Count:", order_count)


# =========================================================
# PART H - AVERAGE ORDER VALUE
# =========================================================

average_order_value = total_sales / order_count

print("\n========== AVERAGE ORDER VALUE ==========")

print(
    "Average Order Value:",
    round(average_order_value, 2)
)


# =========================================================
# PART I - PROFIT MARGIN %
# =========================================================

profit_margin = total_profit / total_sales

print("\n========== PROFIT MARGIN ==========")

print(
    "Profit Margin %:",
    round(profit_margin * 100, 2)
)


# =========================================================
# PART J - SALES BY REGION
# =========================================================

region_sales = (
    df.groupby("Region")["Sales"]
    .sum()
    .sort_values(ascending=False)
)


print("\n========== TOTAL SALES BY REGION ==========")

print(region_sales.round(2))


# =========================================================
# PART K - PROFIT BY REGION
# =========================================================

region_profit = (
    df.groupby("Region")["Profit"]
    .sum()
    .sort_values(ascending=False)
)


print("\n========== TOTAL PROFIT BY REGION ==========")

print(region_profit.round(2))


# =========================================================
# PART L - PROFIT MARGIN BY REGION
# =========================================================

region_summary = (
    df.groupby("Region")
    .agg(
        Total_Sales=("Sales", "sum"),
        Total_Profit=("Profit", "sum")
    )
)


region_summary["Profit_Margin_%"] = (
    region_summary["Total_Profit"]
    / region_summary["Total_Sales"]
) * 100


print("\n========== REGION SUMMARY ==========")

print(region_summary.round(2))


# =========================================================
# PART M - % OF TOTAL SALES
# =========================================================

region_summary["%_of_Total_Sales"] = (
    region_summary["Total_Sales"]
    / total_sales
) * 100


print("\n========== % OF TOTAL SALES ==========")

print(
    region_summary[
        ["Total_Sales", "%_of_Total_Sales"]
    ].round(2)
)


# =========================================================
# PART N - SEGMENT VALIDATION
# =========================================================

segment_sales = (
    df.groupby("Segment")["Sales"]
    .sum()
)


print("\n========== SALES BY SEGMENT ==========")

print(segment_sales.round(2))


# =========================================================
# PART O - CATEGORY VALIDATION
# =========================================================

category_sales = (
    df.groupby("Category")["Sales"]
    .sum()
)


print("\n========== SALES BY CATEGORY ==========")

print(category_sales.round(2))


# =========================================================
# PART P - SOUTH REGION CROSS-CHECK
# =========================================================

south_sales = (
    df[df["Region"] == "South"]["Sales"]
    .sum()
)


print("\n========== SOUTH REGION ==========")

print(
    "South Total Sales:",
    round(south_sales, 2)
)


# =========================================================
# FINAL VALIDATION
# =========================================================

print("\n======================================")
print("DAY 14 PYTHON VALIDATION COMPLETED")
print("======================================")

print(
    "Total Sales:",
    round(total_sales, 2)
)

print(
    "Total Profit:",
    round(total_profit, 2)
)

print(
    "Average Order Value:",
    round(average_order_value, 2)
)

print(
    "Profit Margin %:",
    round(profit_margin * 100, 2)
)

print(
    "Order Count:",
    order_count
)