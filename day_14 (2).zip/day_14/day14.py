# =========================================================
# DAY 14 - POWER BI PYTHON VALIDATION
# =========================================================
# This Python script validates the Power BI results
# using the same Capstone Customers and Orders data.
# =========================================================


# =========================================================
# PART A - IMPORT LIBRARY
# =========================================================

import pandas as pd


# =========================================================
# PART B - LOAD DATA
# =========================================================

customers = pd.read_csv("Capstone_Customers.csv")
orders = pd.read_csv("Capstone_Orders.csv")

print("Customers Shape:", customers.shape)
print("Orders Shape:", orders.shape)


# =========================================================
# PART C - REMOVE DUPLICATES
# =========================================================

customers = customers.drop_duplicates().copy()
orders = orders.drop_duplicates().copy()


# =========================================================
# PART D - CLEAN TEXT COLUMNS
# =========================================================

# Clean Region

customers["Region"] = (
    customers["Region"]
    .astype("string")
    .str.strip()
    .str.title()
)


# Clean Segment

customers["Segment"] = (
    customers["Segment"]
    .astype("string")
    .str.strip()
    .str.title()
)


# Clean Category

orders["Category"] = (
    orders["Category"]
    .astype("string")
    .str.strip()
    .str.title()
)


# =========================================================
# PART E - CONVERT DATA TYPES
# =========================================================

customers["CustomerID"] = pd.to_numeric(
    customers["CustomerID"],
    errors="coerce"
)

orders["CustomerID"] = pd.to_numeric(
    orders["CustomerID"],
    errors="coerce"
)

orders["OrderID"] = pd.to_numeric(
    orders["OrderID"],
    errors="coerce"
)

orders["Sales"] = pd.to_numeric(
    orders["Sales"],
    errors="coerce"
)

orders["Profit"] = pd.to_numeric(
    orders["Profit"],
    errors="coerce"
)

orders["Quantity"] = pd.to_numeric(
    orders["Quantity"],
    errors="coerce"
)

orders["Discount"] = pd.to_numeric(
    orders["Discount"],
    errors="coerce"
)


# =========================================================
# PART F - MERGE ORDERS WITH CUSTOMERS
# =========================================================
# LEFT JOIN keeps all order records.
# This matches the Power BI model validation approach.

df = pd.merge(
    orders,
    customers,
    on="CustomerID",
    how="left"
)

print("\nMerged Dataset Shape:", df.shape)


# =========================================================
# PART G - ESTIMATE MISSING PROFIT
# =========================================================
# Power Query formula:
#
# If Profit is blank:
# Sales × Quantity × (1 - Discount) × 0.308
#
# Otherwise:
# Use existing Profit
# =========================================================

df["Profit_Final"] = df["Profit"]

df.loc[
    df["Profit"].isna(),
    "Profit_Final"
] = (
    df.loc[df["Profit"].isna(), "Sales"]
    * df.loc[df["Profit"].isna(), "Quantity"]
    * (1 - df.loc[df["Profit"].isna(), "Discount"])
    * 0.308
)


print("\nProfit estimation completed.")


# =========================================================
# PART H - BASIC VALIDATION
# =========================================================

print("\n========== REGION VALUES ==========")

print(
    df["Region"]
    .dropna()
    .unique()
)


print("\n========== CATEGORY VALUES ==========")

print(
    df["Category"]
    .dropna()
    .unique()
)


print("\n========== SEGMENT VALUES ==========")

print(
    df["Segment"]
    .dropna()
    .unique()
)


# =========================================================
# PART I - TOTAL SALES
# =========================================================

total_sales = df["Sales"].sum()

print("\n========== TOTAL SALES ==========")

print(
    "Total Sales:",
    round(total_sales, 2)
)


# =========================================================
# PART J - TOTAL PROFIT
# =========================================================

total_profit = df["Profit_Final"].sum()

print("\n========== TOTAL PROFIT ==========")

print(
    "Total Profit:",
    round(total_profit, 2)
)


# =========================================================
# PART K - ORDER COUNT
# =========================================================

order_count = df["OrderID"].nunique()

print("\n========== ORDER COUNT ==========")

print(
    "Order Count:",
    order_count
)


# =========================================================
# PART L - AVERAGE ORDER VALUE
# =========================================================

average_order_value = (
    total_sales / order_count
)

print("\n========== AVERAGE ORDER VALUE ==========")

print(
    "Average Order Value:",
    round(average_order_value, 2)
)


# =========================================================
# PART M - PROFIT MARGIN
# =========================================================

profit_margin = (
    total_profit / total_sales
)

print("\n========== PROFIT MARGIN ==========")

print(
    "Profit Margin %:",
    round(profit_margin * 100, 2)
)


# =========================================================
# PART N - TOTAL SALES BY REGION
# =========================================================

region_sales = (
    df.groupby("Region")["Sales"]
    .sum()
    .sort_values(ascending=False)
)

print("\n========== TOTAL SALES BY REGION ==========")

print(
    region_sales.round(2)
)


# =========================================================
# PART O - TOTAL PROFIT BY REGION
# =========================================================

region_profit = (
    df.groupby("Region")["Profit_Final"]
    .sum()
    .sort_values(ascending=False)
)

print("\n========== TOTAL PROFIT BY REGION ==========")

print(
    region_profit.round(2)
)


# =========================================================
# PART P - REGION SUMMARY
# =========================================================

region_summary = (
    df.groupby("Region")
    .agg(
        Total_Sales=("Sales", "sum"),
        Total_Profit=("Profit_Final", "sum")
    )
)


# Calculate Profit Margin by Region

region_summary["Profit_Margin_%"] = (
    region_summary["Total_Profit"]
    / region_summary["Total_Sales"]
) * 100


print("\n========== REGION SUMMARY ==========")

print(
    region_summary.round(2)
)


# =========================================================
# PART Q - % OF TOTAL SALES BY REGION
# =========================================================

region_summary["%_of_Total_Sales"] = (
    region_summary["Total_Sales"]
    / total_sales
) * 100


print("\n========== % OF TOTAL SALES ==========")

print(
    region_summary[
        [
            "Total_Sales",
            "%_of_Total_Sales"
        ]
    ].round(2)
)


# =========================================================
# PART R - SALES BY SEGMENT
# =========================================================

segment_sales = (
    df.groupby("Segment")["Sales"]
    .sum()
    .sort_values(ascending=False)
)

print("\n========== SALES BY SEGMENT ==========")

print(
    segment_sales.round(2)
)


# =========================================================
# PART S - SALES BY CATEGORY
# =========================================================

category_sales = (
    df.groupby("Category")["Sales"]
    .sum()
    .sort_values(ascending=False)
)

print("\n========== SALES BY CATEGORY ==========")

print(
    category_sales.round(2)
)


# =========================================================
# PART T - SOUTH REGION CROSS-CHECK
# =========================================================

south_sales = (
    df[df["Region"] == "South"]["Sales"]
    .sum()
)

print("\n========== SOUTH REGION ==========")

print(
    "South Total Sales:",
    round(south_sales, 2)
)


# =========================================================
# PART U - MISSING PROFIT CHECK
# =========================================================

missing_profit_count = df["Profit"].isna().sum()

print("\n========== MISSING PROFIT CHECK ==========")

print(
    "Original Missing Profit Rows:",
    missing_profit_count
)


# =========================================================
# PART V - FINAL VALIDATION
# =========================================================

print("\n======================================")
print("DAY 14 PYTHON VALIDATION COMPLETED")
print("======================================")


print(
    "Total Sales:",
    round(total_sales, 2)
)

print(
    "Total Profit:",
    round(total_profit, 2)
)

print(
    "Average Order Value:",
    round(average_order_value, 2)
)

print(
    "Profit Margin %:",
    round(profit_margin * 100, 2)
)

print(
    "Order Count:",
    order_count
)

print(
    "Rows in Final Dataset:",
    len(df)
)

print("======================================")